﻿namespace Roguelike;

class Program
{
    static void Main(string[] args)
    {
        Map map = new Map(96, 48);
    }
}
